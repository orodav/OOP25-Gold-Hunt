package it.unibo.goldhunt.engine.impl;

import org.junit.jupiter.api.Test;

public class MovementRulesTest {

    @Test
    void shouldThrowIfConstructorBoardNull() {}

    @Test
    void shouldThrowIfCaneEnterArgumentsNull() {}

    @Test
    void shouldReturnFalseWhenFromEqualsTo() {}

    @Test
    void shouldThrowIfMustStopArgumentsNull() {}

    @Test
    void shouldReturnBoardStopValue() {}

    @Test
    void shouldThrowIfIsReachableArgumentsNull() {}

    @Test
    void shouldReturnTrueWhenSamePosition() {}

    @Test
    void shouldReturnFalseWhenNoPathExists() {}

    @Test
    void shouldReturnTrueWhenPathExists() {}
}
