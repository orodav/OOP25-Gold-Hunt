package it.unibo.goldhunt.player.impl;

import org.junit.jupiter.api.Test;

public class PlayerOperationsContractTest {

    @Test
    void shouldExposePosition() {}

    @Test
    void shouldExposeLives() {}

    @Test
    void shouldExposeGold() {}

    @Test
    void shouldExposeInventory() {}
}
