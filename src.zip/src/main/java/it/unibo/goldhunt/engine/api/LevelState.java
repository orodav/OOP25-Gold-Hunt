package it.unibo.goldhunt.engine.api;
//davv
public enum LevelState {
    PLAYING, WON, LOSS;
}
