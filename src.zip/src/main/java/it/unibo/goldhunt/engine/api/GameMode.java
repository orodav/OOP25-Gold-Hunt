package it.unibo.goldhunt.engine.api;
//davv
public enum GameMode {
    DIFFICULTY, LEVEL, SHOP;
}
