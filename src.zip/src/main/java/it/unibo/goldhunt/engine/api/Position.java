package it.unibo.goldhunt.engine.api;
//davv
public record Position(int x, int y) {
}
