package it.unibo.goldhunt.engine.api;
//davv
public enum ActionType {
    MOVE, REVEAL, FLAG;
}
