package it.unibo.goldhunt.engine.api;
//davv
public enum Direction {
    UP, DOWN, LEFT, RIGHT;
}
