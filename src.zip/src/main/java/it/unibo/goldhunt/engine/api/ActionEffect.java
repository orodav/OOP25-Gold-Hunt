package it.unibo.goldhunt.engine.api;
//davv
public enum ActionEffect {
    APPLIED, REMOVED, BLOCKED, INVALID, NONE;
}
