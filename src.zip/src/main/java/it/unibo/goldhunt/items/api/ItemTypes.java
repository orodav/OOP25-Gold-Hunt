package it.unibo.goldhunt.items.api;

//luca
public interface ItemTypes extends CellContent{
    
    String getName();

}
