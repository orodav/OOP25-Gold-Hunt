package it.unibo.goldhunt.items.api;

public interface Revealable extends CellContent{
    //marker interface
}
