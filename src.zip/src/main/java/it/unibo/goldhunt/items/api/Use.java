package it.unibo.goldhunt.items.api;
//luca
public interface Use {

    boolean canUse();
}
